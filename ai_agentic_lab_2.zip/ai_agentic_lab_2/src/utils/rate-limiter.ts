export interface RateLimiterOptions {
  requestsPerMinute?: number;
  tokensPerMinute?: number;
  maxConcurrent?: number;
}

export class RateLimiter {
  private requestsPerMinute: number;
  private tokensPerMinute: number;
  private maxConcurrent: number;

  private requestTimestamps: number[] = [];
  private tokenRecords: { timestamp: number; tokens: number }[] = [];
  private currentConcurrent = 0;

  constructor(options: RateLimiterOptions = {}) {
    this.requestsPerMinute = options.requestsPerMinute || 50;
    this.tokensPerMinute = options.tokensPerMinute || 40000;
    this.maxConcurrent = options.maxConcurrent || 5;
  }

  /**
   * Remove records older than 60 seconds (sliding window)
   */
  private pruneOldRecords(): void {
    const now = Date.now();
    const windowStart = now - 60000;

    this.requestTimestamps = this.requestTimestamps.filter((ts) => ts > windowStart);
    this.tokenRecords = this.tokenRecords.filter((record) => record.timestamp > windowStart);
  }

  /**
   * Check if request can proceed under current limits
   */
  public canProceed(estimatedTokens = 1000): boolean {
    this.pruneOldRecords();

    if (this.currentConcurrent >= this.maxConcurrent) return false;
    if (this.requestTimestamps.length >= this.requestsPerMinute) return false;

    const currentTokenSum = this.tokenRecords.reduce((sum, r) => sum + r.tokens, 0);
    if (currentTokenSum + estimatedTokens > this.tokensPerMinute) return false;

    return true;
  }

  /**
   * Wait until a slot becomes available in the sliding window
   */
  public async waitForSlot(estimatedTokens = 1000): Promise<void> {
    while (!this.canProceed(estimatedTokens)) {
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
  }

  /**
   * Acquire execution slot and update internal tracking
   */
  public async acquire<T>(
    operation: () => Promise<T>,
    estimatedTokens = 1000
  ): Promise<T> {
    await this.waitForSlot(estimatedTokens);

    const now = Date.now();
    this.requestTimestamps.push(now);
    this.tokenRecords.push({ timestamp: now, tokens: estimatedTokens });
    this.currentConcurrent++;

    try {
      return await operation();
    } finally {
      this.currentConcurrent = Math.max(0, this.currentConcurrent - 1);
    }
  }
}