// import { logger } from './logger.js';

// export interface RetryOptions {
//   maxRetries?: number;
//   initialDelayMs?: number;
//   backoffFactor?: number;
//   retryableErrors?: string[];
// }

// export async function withRetry<T>(
//   fn: () => Promise<T>,
//   options: RetryOptions = {}
// ): Promise<T> {
//   const {
//     maxRetries = 3,
//     initialDelayMs = 1000,
//     backoffFactor = 2,
//     retryableErrors = ['ECONNRESET', 'ETIMEDOUT', 'rate_limit', '503', '529', 'overloaded']
//   } = options;

//   let lastError: unknown;
//   let delay = initialDelayMs;

//   for (let attempt = 1; attempt <= maxRetries; attempt++) {
//     try {
//       return await fn();
//     } catch (error) {
//       lastError = error;
//       const message = error instanceof Error ? error.message : String(error);

//       const isRetryable =
//         retryableErrors.length === 0 ||
//         retryableErrors.some((keyword) =>
//           message.toLowerCase().includes(keyword.toLowerCase())
//         );

//       if (attempt === maxRetries || !isRetryable) {
//         throw error;
//       }

//       logger.warn(`Retry attempt ${attempt}/${maxRetries} after error: ${message}. Waiting ${delay}ms...`);
//       await new Promise((resolve) => setTimeout(resolve, delay));
//       delay *= backoffFactor;
//     }
//   }

//   throw lastError;
// }

// export async function withTimeout<T>(
//   promise: Promise<T>,
//   timeoutMs: number,
//   operationName = 'Operation'
// ): Promise<T> {
//   let timer: NodeJS.Timeout;

//   const timeoutPromise = new Promise<never>((_, reject) => {
//     timer = setTimeout(() => {
//       reject(new Error(`${operationName} timed out after ${timeoutMs}ms`));
//     }, timeoutMs);
//   });

//   try {
//     return await Promise.race([promise, timeoutPromise]);
//   } finally {
//     clearTimeout(timer!);
//   }
// }
import { logger } from './logger.js';

export interface RetryOptions {
  maxAttempts?: number;
  initialDelayMs?: number;
  backoffFactor?: number;
  retryableErrors?: string[];
}

export class AppError extends Error {
  code?: string;
  constructor(message: string, code?: string) {
    super(message);
    this.name = 'AppError';
    this.code = code;
  }
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const {
    maxAttempts = 3,
    initialDelayMs = 10,
    backoffFactor = 2,
    retryableErrors,
  } = options;

  let delay = initialDelayMs;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);

      const isRetryable =
        !retryableErrors ||
        retryableErrors.some((keyword) =>
          message.toLowerCase().includes(keyword.toLowerCase())
        );

      if (attempt === maxAttempts) {
        const failureError = new AppError(
          `Operation failed after ${maxAttempts} attempts: ${message}`,
          'MAX_RETRIES_EXCEEDED'
        );
        throw failureError;
      }

      if (!isRetryable) {
        throw error;
      }

      logger.warn(
        `Retry attempt ${attempt}/${maxAttempts} after error: ${message}. Waiting ${delay}ms...`
      );
      await new Promise((resolve) => setTimeout(resolve, delay));
      delay *= backoffFactor;
    }
  }

  throw new AppError('Max retries exceeded', 'MAX_RETRIES_EXCEEDED');
}

export async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number,
  operationName = 'Operation'
): Promise<T> {
  let timer: NodeJS.Timeout;

  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      reject(
        new AppError(
          `${operationName} timed out after ${timeoutMs}ms`,
          'TIMEOUT_EXCEEDED'
        )
      );
    }, timeoutMs);
  });

  try {
    return await Promise.race([promise, timeoutPromise]);
  } finally {
    clearTimeout(timer!);
  }
}