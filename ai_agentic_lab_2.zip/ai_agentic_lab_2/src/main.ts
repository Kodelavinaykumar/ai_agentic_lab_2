// import { CodeReviewOrchestrator } from './orchestrator.js';
// import { ReportGenerator } from './utils/report-generator.js';
// import { logger } from './utils/logger.js';
// import * as path from 'path';

// async function main() {
//   const args = process.argv.slice(2);
//   const [owner, repo, prNumberStr] = args;

//   if (!owner || !repo || !prNumberStr) {
//     console.error('Usage: npm run dev -- <owner> <repo> <prNumber>');
//     process.exit(1);
//   }

//   const prNumber = parseInt(prNumberStr, 10);
//   if (isNaN(prNumber) || prNumber <= 0) {
//     console.error('Error: prNumber must be a positive integer.');
//     process.exit(1);
//   }

//   // Validate environment credentials
//   const hasApiKey = Boolean(process.env.ANTHROPIC_API_KEY);
//   const hasAwsCreds = Boolean(
//     process.env.AWS_ACCESS_KEY_ID &&
//     process.env.AWS_SECRET_ACCESS_KEY &&
//     process.env.AWS_REGION
//   );

//   if (!hasApiKey && !hasAwsCreds) {
//     logger.warn(
//       'Neither ANTHROPIC_API_KEY nor AWS Bedrock credentials found in process.env. Proceeding with default environment credentials if available.'
//     );
//   }

//   try {
//     logger.info(`Starting code review for ${owner}/${repo} PR #${prNumber}...`);

//     const orchestrator = new CodeReviewOrchestrator();
//     const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);

//     const projectRoot = process.env.PROJECT_ROOT || process.cwd();
//     const outputDir = path.join(projectRoot, 'reports');

//     const generator = new ReportGenerator({ outputDir });
//     const generatedFiles = await generator.generateAll(report);

//     logger.info('Review completed successfully!');
//     logger.info(`Generated report files in ${outputDir}:`);
//     generatedFiles.forEach((file) => logger.info(` - ${file}`));
//   } catch (error) {
//     logger.error('Failed to complete pull request review:', error);
//     process.exit(1);
//   }
// }

// main();
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator } from './utils/report-generator.js';
import { logger } from './utils/logger.js';
import { validateEnvironment } from './config/env.js';
import * as path from 'path';

async function main() {
  const args = process.argv.slice(2);
  const [owner, repo, prNumberStr] = args;

  if (!owner || !repo || !prNumberStr) {
    console.error('Usage: npm run dev -- <owner> <repo> <prNumber>');
    process.exit(1);
  }

  const prNumber = parseInt(prNumberStr, 10);
  if (isNaN(prNumber) || prNumber <= 0) {
    console.error('Error: prNumber must be a positive integer.');
    process.exit(1);
  }

  try {
    validateEnvironment();

    logger.info(`Starting code review for ${owner}/${repo} PR #${prNumber}...`);

    const orchestrator = new CodeReviewOrchestrator();
    const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);

    const projectRoot = process.env.PROJECT_ROOT || process.cwd();
    const outputDir = path.join(projectRoot, 'reports');

    const generator = new ReportGenerator({ outputDir });
    const generatedFiles = await generator.generateAll(report);

    logger.info('Review completed successfully!');
    logger.info(`Generated report files in ${outputDir}:`);
    generatedFiles.forEach((file) => logger.info(` - ${file}`));
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();