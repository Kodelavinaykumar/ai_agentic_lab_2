import { withRetry, withTimeout } from './utils/error-handler.js';
import { RateLimiter } from './utils/rate-limiter.js';
import { query } from '@anthropic-ai/claude-agent-sdk';
import zodToJsonSchema from 'zod-to-json-schema';
import { mcpServersConfig } from './config/mcp.config.js';
import {
  codeQualityAnalyzerAgent,
  testCoverageAnalyzerAgent,
  refactoringSuggesterAgent,
} from './agents/index.js';
import { ORCHESTRATOR_PROMPT } from './prompts/index.js';
import { ReviewReportSchema } from './types/report-types.js';
import type { ReviewReport } from './types/report-types.js';

export interface OrchestratorOptions {
  model?: string;
  maxRetries?: number;
}

export class CodeReviewOrchestrator {
  private model: string;
  private maxRetries: number;
  private rateLimiter: RateLimiter;

  constructor(options: OrchestratorOptions = {}) {
    this.model = options.model || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5-20250929';
    this.maxRetries = options.maxRetries ?? 3;
    this.rateLimiter = new RateLimiter({ requestsPerMinute: 30, tokensPerMinute: 40000 });
  }

  /**
   * Review a pull request using parallel subagent analysis
   */
  async reviewPullRequest(owner: string, repo: string, prNumber: number): Promise<ReviewReport> {
    const prompt = `${ORCHESTRATOR_PROMPT}\n\nAnalyze pull request #${prNumber} for repository ${owner}/${repo}.`;

    // Convert Zod schema to JSON Schema for structured output validation
    const jsonSchema = zodToJsonSchema(ReviewReportSchema as any, { $refStrategy: 'root' });

    // Execute query throttled by rateLimiter and wrapped in withRetry + withTimeout
    const finalResult = await this.rateLimiter.acquire(async () => {
      return await withRetry(async () => {
        const queryExecution = (async () => {
          const response = query({
            prompt,
            options: {
              model: this.model,
              mcpServers: mcpServersConfig,
              allowedTools: [
                'Task',
                'mcp__github__get_pull_request',
                'mcp__github__get_pull_request_files',
                'mcp__eslint__lint-files',
              ],
              agents: {
                'code-quality-analyzer': codeQualityAnalyzerAgent,
                'test-coverage-analyzer': testCoverageAnalyzerAgent,
                'refactoring-suggester': refactoringSuggesterAgent,
              },
              outputFormat: {
                type: 'json_schema',
                schema: jsonSchema as Record<string, unknown>,
              },
            },
          });

          let result: unknown = null;
          for await (const message of response) {
            if (message.type === 'result' && message.subtype === 'success') {
              result = message.structured_output ?? message.result;
            }
          }

          if (!result) {
            throw new Error('Failed to retrieve structured output from orchestrator.');
          }

          return result;
        })();

        return await withTimeout(queryExecution, 180000);
      });
    });

    // Parse and validate final JSON output
    const rawData =
      typeof finalResult === 'string'
        ? JSON.parse(finalResult)
        : finalResult;
    const parsed = ReviewReportSchema.safeParse(rawData);

    if (!parsed.success) {
      throw new Error(`ReviewReport validation failed: ${parsed.error.message}`);
    }

    return parsed.data;
  }
}
