import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts/refactoring-suggester.prompt.js';

export const refactoringSuggesterAgent: AgentDefinition = {
  description: 'Suggests architectural improvements, modern design patterns, modularization, and code cleanup.',
  prompt: REFACTORING_SUGGESTER_PROMPT,
  tools: ['Skill', 'ReadFile', 'Grep', 'Glob'],
  model: 'inherit',
};