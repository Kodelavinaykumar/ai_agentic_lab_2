import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts/test-coverage-analyzer.prompt.js';

export const testCoverageAnalyzerAgent: AgentDefinition = {
  description: 'Evaluates test coverage, identifies untested edge cases, and suggests missing test cases.',
  prompt: TEST_COVERAGE_ANALYZER_PROMPT,
tools: ['Skill', 'ReadFile', 'Grep', 'Glob'],
  model: 'inherit',
};