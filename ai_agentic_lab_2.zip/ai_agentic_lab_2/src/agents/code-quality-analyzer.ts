import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/code-quality-analyzer.prompt.js';

export const codeQualityAnalyzerAgent: AgentDefinition = {
  description: 'Analyzes code for security vulnerabilities, performance issues, code smells, and best practice violations.',
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
  tools: ['Skill', 'ReadFile', 'Grep', 'Glob'],
  model: 'inherit',
};