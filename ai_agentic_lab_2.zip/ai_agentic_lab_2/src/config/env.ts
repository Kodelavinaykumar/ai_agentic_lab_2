// src/config/env.ts
import dotenv from 'dotenv';
dotenv.config();

export function validateEnvironment(): void {
  const hasAnthropicKey = Boolean(process.env.ANTHROPIC_API_KEY);
  const hasAwsCreds = Boolean(
    process.env.AWS_ACCESS_KEY_ID &&
    process.env.AWS_SECRET_ACCESS_KEY &&
    process.env.AWS_REGION
  );

  const missing: string[] = [];

  if (!hasAnthropicKey && !hasAwsCreds) {
    missing.push('ANTHROPIC_API_KEY or AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY/AWS_REGION');
  }

  if (!process.env.GITHUB_TOKEN) {
    missing.push('GITHUB_TOKEN');
  }

  if (missing.length > 0) {
    throw new Error(
      `Missing required environment variables: ${missing.join(', ')}. ` +
      'Create a .env file from .env.example and add the required credentials.'
    );
  }
}