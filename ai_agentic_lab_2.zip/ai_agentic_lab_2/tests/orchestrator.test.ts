import {
  describe,
  it,
  expect,
  vi,
  beforeEach,
} from 'vitest';

import { mkdtemp, readFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { basename, join } from 'path';

vi.mock('@anthropic-ai/claude-agent-sdk', () => ({
  query: vi.fn(),
}));

import { query } from '@anthropic-ai/claude-agent-sdk';
import { CodeReviewOrchestrator } from '../src/orchestrator.js';
import {
  ReviewReportSchema,
  type ReviewReport,
} from '../src/types/report-types.js';
import {
  withRetry,
  withTimeout,
} from '../src/utils/error-handler.js';
import { RateLimiter } from '../src/utils/rate-limiter.js';
import { ReportGenerator } from '../src/utils/report-generator.js';

const sampleReport: ReviewReport = {
  pullRequest: {
    owner: 'airaamane',
    repo: 'simple-todo-app',
    number: 1,
  },

  fileReviews: [
    {
      file: 'src/app.ts',

      codeQuality: {
        file: 'src/app.ts',
        issues: [
          {
            line: 10,
            severity: 'medium',
            category: 'maintainability',
            description: 'Function is doing multiple tasks.',
            suggestion: 'Extract validation into a helper function.',
          },
        ],
        overallScore: 85,
        summary: 'Code quality is generally good.',
      },

      testCoverage: {
        file: 'src/app.ts',
        hasTests: false,
        testFiles: [],
        untestedPaths: [
          {
            type: 'function',
            location: 'addTodo',
            priority: 'high',
            reasoning: 'Core functionality should be tested.',
            suggestedTest: 'Test adding a valid todo item.',
          },
        ],
        coverageEstimate: 50,
        summary: 'Additional tests are required.',
      },

      refactorings: {
        file: 'src/app.ts',
        suggestions: [
          {
            type: 'extract-function',
            location: 'addTodo',
            impact: 'medium',
            description: 'Extract validation logic.',
            before: 'function addTodo() { /* validation + insert */ }',
            after: 'validateTodo(); addTodo();',
            benefits: 'Improves readability and maintainability.',
          },
        ],
        summary: 'One useful refactoring opportunity was found.',
      },
    },
  ],

  summary: {
    totalFiles: 1,
    overallScore: 85,
    criticalIssues: 0,
    highPriorityTests: 1,
    refactoringOpportunities: 1,
  },

  recommendations: [
    {
      priority: 'high',
      category: 'Testing',
      description: 'Add tests for addTodo.',
      files: ['src/app.ts'],
    },
  ],

  metadata: {
    analyzedAt: '2026-09-24T00:00:00.000Z',
    duration: 1200,
    agentVersions: {
      codeQuality: '1.0.0',
      testCoverage: '1.0.0',
      refactoring: '1.0.0',
    },
  },
};

describe('ReviewReportSchema', () => {
  it('accepts a valid complete review report', () => {
    const result = ReviewReportSchema.safeParse(sampleReport);

    expect(result.success).toBe(true);

    if (result.success) {
      expect(result.data.pullRequest.owner).toBe('airaamane');
      expect(result.data.fileReviews).toHaveLength(1);
      expect(result.data.summary.overallScore).toBe(85);
    }
  });

  it('rejects an invalid review report', () => {
    const invalidReport = JSON.parse(JSON.stringify(sampleReport));

    invalidReport.fileReviews[0].codeQuality.overallScore = 150;

    const result = ReviewReportSchema.safeParse(invalidReport);

    expect(result.success).toBe(false);
  });
});

describe('Error handling utilities', () => {
  it('withRetry retries failed operations and eventually succeeds', async () => {
    const operation = vi
      .fn()
      .mockRejectedValueOnce(new Error('temporary failure 1'))
      .mockRejectedValueOnce(new Error('temporary failure 2'))
      .mockResolvedValue('success');

    const result = await withRetry(operation, {
      maxAttempts: 3,
      initialDelayMs: 0,
      backoffFactor: 1,
      jitter: false,
    });

    expect(result).toBe('success');
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it('withRetry throws after the maximum number of attempts', async () => {
    const operation = vi.fn().mockRejectedValue(new Error('permanent failure'));

    await expect(
      withRetry(operation, {
        maxAttempts: 2,
        initialDelayMs: 0,
        jitter: false,
      })
    ).rejects.toMatchObject({
      code: 'MAX_RETRIES_EXCEEDED',
    });

    expect(operation).toHaveBeenCalledTimes(2);
  });

  it('withTimeout rejects slow operations with TIMEOUT_EXCEEDED', async () => {
    const neverFinishes = new Promise<string>(() => {});

    await expect(
      withTimeout(neverFinishes, 10, 'Slow operation')
    ).rejects.toMatchObject({
      code: 'TIMEOUT_EXCEEDED',
    });
  });
});

describe('RateLimiter', () => {
  it('enforces the configured request-per-minute limit', async () => {
    const limiter = new RateLimiter({
      requestsPerMinute: 1,
      tokensPerMinute: 5000,
      maxConcurrent: 2,
    });

    expect(limiter.canProceed(500)).toBe(true);

    const result = await limiter.acquire(
      async () => 'completed',
      500
    );

    expect(result).toBe('completed');

    // The single request-per-minute allowance has now been consumed.
    expect(limiter.canProceed(500)).toBe(false);
  });

  it('blocks requests that exceed the configured token budget', () => {
    const limiter = new RateLimiter({
      requestsPerMinute: 10,
      tokensPerMinute: 1000,
      maxConcurrent: 2,
    });

    expect(limiter.canProceed(500)).toBe(true);
    expect(limiter.canProceed(1500)).toBe(false);
  });
});

describe('ReportGenerator', () => {
  it('generates JSON, Markdown, and HTML report files', async () => {
    const tempDirectory = await mkdtemp(
      join(tmpdir(), 'code-review-report-')
    );

    try {
      const generator = new ReportGenerator({
        outputDir: tempDirectory,
      });

      const generatedFiles = await generator.generateAll(sampleReport);

      expect(generatedFiles).toHaveLength(3);

      const names = generatedFiles.map((file) => basename(file)).sort();

      expect(names).toEqual([
        'airaamane_simple-todo-app_1.html',
        'airaamane_simple-todo-app_1.json',
        'airaamane_simple-todo-app_1.md',
      ]);

      const jsonFile = generatedFiles.find((file) =>
        file.endsWith('.json')
      );

      expect(jsonFile).toBeDefined();

      const savedReport = JSON.parse(
        await readFile(jsonFile!, 'utf8')
      );

      expect(savedReport.pullRequest.owner).toBe('airaamane');
      expect(savedReport.pullRequest.number).toBe(1);

      const markdownFile = generatedFiles.find((file) =>
        file.endsWith('.md')
      );

      const markdown = await readFile(markdownFile!, 'utf8');

      expect(markdown).toContain('Code Review Report');
      expect(markdown).toContain('Overall Score');
    } finally {
      await rm(tempDirectory, {
        recursive: true,
        force: true,
      });
    }
  });
});

describe('CodeReviewOrchestrator', () => {
  const queryMock = vi.mocked(query);

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('configures the SDK with the model, MCP tools, and all three subagents', async () => {
    queryMock.mockImplementation(() => {
      return (async function* () {
        yield {
          type: 'result',
          subtype: 'success',
          result: JSON.stringify(sampleReport),
          structured_output: sampleReport,
        } as any;
      })() as any;
    });

    const orchestrator = new CodeReviewOrchestrator({
      model: 'test-model',
    });

    const result = await orchestrator.reviewPullRequest(
      'airaamane',
      'simple-todo-app',
      1
    );

    expect(result).toEqual(sampleReport);
    expect(queryMock).toHaveBeenCalledTimes(1);

    const sdkRequest = queryMock.mock.calls[0][0] as any;

    expect(sdkRequest.prompt).toContain(
      'airaamane/simple-todo-app'
    );
    expect(sdkRequest.prompt).toContain('#1');

    expect(sdkRequest.options.model).toBe('test-model');

    expect(sdkRequest.options.allowedTools).toContain(
      'mcp__github__get_pull_request'
    );

    expect(Object.keys(sdkRequest.options.agents).sort()).toEqual(
      [
        'code-quality-analyzer',
        'refactoring-suggester',
        'test-coverage-analyzer',
      ].sort()
    );
  });

  it('rejects SDK output that does not satisfy ReviewReportSchema', async () => {
    const invalidReport = JSON.parse(JSON.stringify(sampleReport));

    invalidReport.recommendations[0].priority = 'urgent';

    queryMock.mockImplementation(() => {
      return (async function* () {
        yield {
          type: 'result',
          subtype: 'success',
          result: JSON.stringify(invalidReport),
          structured_output: invalidReport,
        } as any;
      })() as any;
    });

    const orchestrator = new CodeReviewOrchestrator();

    await expect(
      orchestrator.reviewPullRequest(
        'airaamane',
        'simple-todo-app',
        1
      )
    ).rejects.toThrow('ReviewReport validation failed');
  });
});

/**
 * LIVE INTEGRATION TEST EVIDENCE
 *
 * The external integration path is exercised manually with:
 *
 *   npm run dev -- airaamane simple-todo-app 1
 *
 * That command requires a funded ANTHROPIC_API_KEY/Vocareum account
 * and access to the external GitHub MCP service.
 *
 * The automated tests above mock only the external Claude SDK boundary,
 * while still exercising the real orchestrator validation, schemas,
 * retry/timeout utilities, rate limiter, and report generation logic.
 */
