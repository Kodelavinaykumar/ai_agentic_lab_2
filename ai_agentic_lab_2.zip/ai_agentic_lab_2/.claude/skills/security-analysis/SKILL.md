# Security Analysis Skill

## Best Practices
- Scan for hardcoded credentials, API keys, and sensitive tokens.
- Identify injection vulnerabilities (SQL, script, command).
- Validate input sanitization and boundary checks.
- Enforce least privilege access patterns.
