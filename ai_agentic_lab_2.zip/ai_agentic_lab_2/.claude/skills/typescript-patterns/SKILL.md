# TypeScript Patterns Skill

## Best Practices
- Enforce strict typing; avoid `any`.
- Utilize discriminated unions for structured state handling.
- Prefer interfaces or explicit type aliases for data contracts.
- Ensure strict null and undefined checks.
